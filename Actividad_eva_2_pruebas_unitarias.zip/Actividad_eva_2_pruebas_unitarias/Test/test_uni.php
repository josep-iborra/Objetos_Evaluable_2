<?php

	use PHPUnit\Framework\TestCase;
	include "../index.php";

	final class test_uni extends TestCase
	{
		public function testEmpleado()
		{
			$persona1 = new carnicero("Diego","Lopez",false);
			$persona1->todo();

			$target = $persona1->todo();
			$expected = false;
			$this->assertEquals($expected,$target);
		}
		public function testCliente()
		{
			$persona4 = new persona("Vicente", "Costa", true);   	
			$persona4->caracteristicas();

			$target = $persona4->caracteristicas();
			$expected = false;
			$this->assertEquals($expected,$target);
		}

		
	}
?>