<?php 
    require_once "personas.php";
    
     
     
    class pescadero extends persona
    {
    	
    	public function gremio()
    	{
    		if ($this->cliente == false) {
    			echo $this->nombre." es pescadero<br>";
    		}
    		
    	}
    	public function todo(){
    		$this->caracteristicas();
    		$this->gremio();
    		$this->atender();
    		$this->comprar();
    		
    	}
    }



 ?>