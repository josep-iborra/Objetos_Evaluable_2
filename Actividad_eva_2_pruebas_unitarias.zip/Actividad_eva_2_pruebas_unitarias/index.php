<?php   
    
    require_once "interfaces.php";
    require_once "personas.php";
    require_once "pescadero.php";
    require_once "carnicero.php";
    require_once "frutero.php";


    $persona1 = new carnicero("Diego","Lopez",false);
    $persona1->todo();


    $persona2 = new pescadero("Concha", "Garcia", false);
    $persona2->todo();

    $persona3 = new frutero("David", "Zaragoza", false);
    $persona3->todo();

    $persona4 = new persona("Vicente", "Costa", true);
    $persona4->caracteristicas();
    $persona4->atender();
    $persona4->comprar();

?>