<?php 
    require_once "personas.php";
    
     
     
    class frutero extends persona
    {
    	
    	public function gremio()
    	{
    		if ($this->cliente == false) {
    			echo $this->nombre." es frutero<br>";
    		}
    		
    	}
    	public function todo(){
    		$this->caracteristicas();
    		$this->gremio();
    		$this->atender();
    		$this->comprar();
    		
    	}
    }



 ?>