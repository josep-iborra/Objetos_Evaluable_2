<?php 
	require_once "interfaces.php";

	class persona implements informacion{
    protected $nombre;
    protected $apellido;
    protected $cliente=false;

   
    public function __construct($nombre,$apellido,$cliente){
        $this->nombre=$nombre;
        $this->apellido=$apellido;
        $this->cliente=$cliente;
    }

    public function getNombre(){
        return $this->nombre;
    }
    public function setNombre($nombre){
        $this->nombre=$nombre;
    }
    public function getApellido(){
        return $this->apellido;
    }
    public function setApellido($apellido){
        $this->apellido=$apellido;
    }
    public function getCliente(){
        return $this->cliente;
    }
    public function setCliente($cliente){
        $this->cliente=$cliente;
    }

    public function caracteristicas(){
			if($this->cliente == false){
				echo "Es un trabajador<br>";
			}else{
				echo "Es un cliente<br>";
			}
		}
	public function atender(){
		if ($this->cliente == false) {
			echo $this->nombre." ".$this->apellido." ha atendido un cliente<br>" ;
		}else{
			echo $this->nombre." ".$this->apellido." ha sido atendido por un trabajador<br>";
		}
	}
	public function comprar(){
		if ($this->cliente == false) {
			echo $this->nombre." ".$this->apellido." ha repuesto sus estantes<br><br><br>" ;
		}else{
			echo $this->nombre." ".$this->apellido." ha comprado muchos productos<br><br><br>";
		}
	}

    }



 ?>