<?php
    interface informacion{
        public function comprar();
        public function atender();
    }

?>